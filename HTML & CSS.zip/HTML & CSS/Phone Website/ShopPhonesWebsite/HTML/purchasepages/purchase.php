<?php

$con = mysql_connect("localhost","root") or die("not connected");

$mydb = mysql_select_db("purchases") or die("no db found");

$sql = "DELETE FROM orders";

if(isset($_POST['submit'])){
	$phone = $_POST['phone'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$address = $_POST['address'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$zipcode = $_POST['zipcode'];
	$email = $_POST['email'];
	$phonenumber = $_POST['phonenumber'];
	$cardnumber = $_POST['cardnumber'];
	$purchaseoption = $_POST['purchaseoption'];
	
	$query = "insert into orders (phone,firstname,lastname,address,city,state,zipcode,email,phonenumber,cardnumber,purchaseoption) values
	('$phone','$firstname','$lastname','$address','$city','$state','$zipcode','$email','$phonenumber','$cardnumber','$purchaseoption')";
	if(mysql_query($query)){
		echo "<h3> Purchase Successful</h3>";
	}

}
?>