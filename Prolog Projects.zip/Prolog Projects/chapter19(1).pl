/*Leszek Piatkiewicz*/
/*Chapter 19 Exercises*/
/*CSC 3750 Spring 2016*/

/*Facts*/

females([brandy, ann, mary, susan, jennifer, jane, susie, jill, linda]).

males([joseph, brandon, jim, james, tom, john, clark, bob, steven, jason, bill, jude]).
males([mark]).

parent(adam,mary).
parent(mary,susan).
parent(jim,tom).
parent(jim,mark).
parent(steven,bill).
parent(mary,clark).
parent(mary,jim).
parent(clark,steven).

/*Predicates*/

male(X) :- 	males(L),
			member(X,L).

female(X) :- females(L),
			 member(X,L).

/*Exercise 19.1*/

mother(X,Y) :- 	female(X),
				parent(X,Y).
				
sibling(X,Y) :- parent(P,X),
				parent(P,Y),
				not(X=Y).


ancestor(X,Y) :- parent(X,Y).

ancestor(X,Y) :- parent(P,Y),
				 ancestor(X,P).	

grandmother(X,Y) :- female(X),
					parent(X,P),
					parent(P,Y).

/* Exercise 19.7 */

third([_,_,Y|_],Y).

/*Exercise 19.13*/

evenSize([]).

evenSize([_,_|T]) :- evenSize(T).















































