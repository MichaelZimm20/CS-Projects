package uncp.csc1760.exams.s2014.midterm;

import java.util.Scanner;

/**
 * Using meters the program will calculates the number of kilometers that many
 * meters represents and the number of meters left over.
 * 
 * @author maz002
 * @version 2014.13.3
 * 
 */
public class Distance {
	/**
	 * 
	 * Using meters the program will calculates the number of kilometers that
	 * many meters represents and the number of meters left over.
	 * 
	 * 
	 * "Charlotte is 3456m away or 3km and 546m away"
	 * "Denver is 70m away or 0km and 70m away"
	 * "Pembroke is -546m away or 0km and -456m away"
	 * 
	 * @param args
	 *            Command like Arguments.
	 */

	public static void main(String[] args) {
		// Prompt the Scanner Object
		Scanner scan = new Scanner(System.in);

		// used int ,string, and constant to read in location, meters , and
		// kilometers
		String location;
		int meters;
		final int KILO_METERS = 1000;

		// Prompts the input for the Scanner object
		System.out.println("Enter the Location : ");
		location = scan.nextLine();

		System.out.println("Enter the distance (in meters) : ");
		meters = scan.nextInt();

		// Calculations for number of kilometers and amount leftover
		int kilometers = meters / KILO_METERS;
		int leftOver = meters % KILO_METERS;

		// Output reading out all the variables :location, meters, kilometers
		// and amount leftover
		System.out.println("Location :\t\t" + location);
		System.out.println("Number of Meters :\t" + meters);
		System.out.println("Number of Kilometers :\t" + kilometers);
		System.out.println("Amount LeftOver :\t" + leftOver);

		System.out.println("\n" + location + " is " + meters + "m away or "
				+ kilometers + "km and " + leftOver + "m away.");

		scan.close();

	}

}
