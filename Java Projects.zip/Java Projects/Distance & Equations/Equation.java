package uncp.csc1760.exams.s2014.midterm;

import java.util.Scanner;
import java.text.DecimalFormat;

/**
 * This program will read in two numbers and calculate the result using a
 * formula.
 * 
 * r = sqrt(abs(x+y) / 3 )
 * 
 * 
 * @author maz002
 * @version 2014.13.3
 * 
 */

public class Equation {

	/**
	 * This program will read in two numbers and calculate the result using a
	 * formula. r = sqrt(abs(x+y) / 3 )
	 * 
	 * Read in and x and y Prompt the scanner Object and Formula Use abs and
	 * sqrt Output an message of the result of x and y.
	 * 
	 * 
	 * 
	 * " X = -50 , Y = 24 result  = 2.83" " X = 46 , Y = 13 result  = 4.36"
	 * " X = -552 , Y = -220 result  = 16.03"
	 * 
	 * 
	 * 
	 * 
	 * @param args
	 *            Command like Arguments.
	 */

	public static void main(String[] args) {

		// Prompt the Scanner Object
		Scanner scan = new Scanner(System.in);

		// Read in the x and y and 3(divisor) as a constant
		int x;
		int y;

		final int DIVIDED_BY = 3;

		// Prompt the decimal formatter for the RESULT
		DecimalFormat formatter = new DecimalFormat("0.0#");

		// Prompts the input for the Scanner object
		System.out.println("Enter in the X value : ");
		x = scan.nextInt();

		System.out.println("Enter in the Y value : ");
		y = scan.nextInt();

		// Calculations and output for x, y, and result
		double result = Math.sqrt((Math.abs(x + y)) / DIVIDED_BY);

		System.out.println("The value of X is: " + x);
		System.out.println("The value of y is: " + y);
		System.out.println("The result of X and Y is: "
				+ formatter.format(result));

		scan.close();

	}

}
