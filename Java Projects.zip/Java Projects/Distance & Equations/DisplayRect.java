package uncp.csc1760.exams.s2014.midterm;


import java.awt.Point;
import java.awt.Rectangle;

/**
 * This program will create a Rectangle object with a specified position and
 * width and height and will then be printed out to the screen.
 * 
 * 
 * @author maz002
 * @version 2014.13.3
 * 
 */

public class DisplayRect {

	/**
	 * This program will create a Rectangle object with a specified position and
	 * width and height and will then be printed out to the screen.
	 * 
	 * 
	 * 
	 * With a position of (5,10) With a width of 30 With a height of 50
	 * 
	 * It will then use a method to change the size of the Rectangle: With a
	 * width of 100 With a height of 20
	 * 
	 * The result will be printed to the screen.
	 * 
	 * 
	 * @param args
	 *            Command Like Arguments.
	 */
	public static void main(String[] args) {

		// Prompts the First position and width and height
		Point point = new Point(5, 10);

		Point point2 = new Point();

		Rectangle position = new Rectangle();

	}

}
