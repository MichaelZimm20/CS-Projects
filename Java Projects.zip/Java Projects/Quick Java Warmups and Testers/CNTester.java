package uncp.csc1850.homework;

import java.util.Scanner;

/**
 * 
 * This class will test the previous ComplexNumber class .
 * 
 * @author maz002
 * @version 2014.20.3
 */

public class CNTester {

	/**
	 * Read in the real and imaginary numbers from the previous class. Then
	 * output the conjugate version of those numbers
	 * 
	 * @param args
	 *            Command like arguments
	 */
	public static void main(String[] args) {

		// Reading in the doubles for the real part, imaginary part, and real
		// number
		double realPart;
		double imaginaryPart;

		double real;

		// Using the scanner object to enter in the real part, imaginary part,
		// and real number
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter a real number:");
		realPart = scan.nextDouble();
		System.out.println("Enter a imaginary number:");
		imaginaryPart = scan.nextDouble();
		System.out.println("Enter a Real :");
		real = scan.nextDouble();

		// Creates the ComplexNumber object to bring in the values from the CN
		// class.
		ComplexNumber realImag;
		realImag = new ComplexNumber(realPart, imaginaryPart);

		ComplexNumber realMag;
		realMag = new ComplexNumber(real);

		// Output the original , conjugated, and real part
		System.out.println("\nOriginal :\t\t" + realImag);
		System.out.println("The Conjugate :\t\t" + realImag.conjugate());
		System.out.println("Real Part :\t\t" + realMag);

		ComplexNumber c1 = new ComplexNumber(realImag);
		System.out.println("\nCopy Constructor: " + c1);
		ComplexNumber c2 = new ComplexNumber();
		System.out.println("\nNull Constructor: " + c2);

		System.out.println("\nAddition: " + realImag.add(realMag));

		System.out.println("\nSubtraction: " + realImag.subtract(realMag));

		System.out.println("\nMultiplication: " + realImag.multiply(realMag));

		// Closing the Scanner object
		scan.close();

	}
}
