package uncp.csc1850.homework;

public class RadixTest {

	public static void main(String args[]){
		
		for (int i = 3; i < 37; i++){
			
			System.out.print(Integer.parseInt("21",i) +  " ");
			
		}
		System.out.println();
		
		for (int j = 11; j < 37; j++){
			System.out.print(Integer.parseInt("A0", j)+ " ");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
