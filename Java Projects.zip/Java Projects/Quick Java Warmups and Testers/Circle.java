package uncp.csc1850.examples;

public class Circle implements IArea {
	
	private double rad;
	
	public Circle(double r){
		rad = r;
	}
	
	public double getArea(){
		return rad * rad  * Math.PI;	//TODO
	}
	
	
	public double getRadius(){
		return rad;
	}
}
