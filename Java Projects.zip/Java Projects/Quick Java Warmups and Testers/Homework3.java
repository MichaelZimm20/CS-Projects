package uncp.csc1850.homework;

public class Homework3 {

	
	public static void main(String args[]){

		
		
		StringBuilder s1 = new StringBuilder("CSC 1850"); // Note that there is a space between words
		
		StringBuilder s2 = new StringBuilder("Spring 2015"); // Note that there is a space between words
		
		s1.append(" is fun"); // Note that there is a space in front of is and a space between is and fun
		s1.append(s2).length();
		s2.insert(0,"Java "); //Note that there is a space after 2nd a
		System.out.println(s1.charAt(2));
		System.out.println(s2.charAt(s2.length() - 1));
		System.out.println(s1.length());
		System.out.println(s1.deleteCharAt(6));
		System.out.println(s1.delete(2,6));
		System.out.println(s1.reverse());
		System.out.println(s1.replace(0,3, "Java"));
		System.out.println(s1.substring(0,6));
		System.out.println(s1.substring(5));
		
		
		
		
		
		
		
		
		
		
		
		System.out.println(s1);
		System.out.println(s2);
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
