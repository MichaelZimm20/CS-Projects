package uncp.csc1850.homework;

public class Hanoi {

	
	public static void main (String[] args){
		int n = 4;
		System.out.println("Here are the instructions how to move " + n + " disks from Peg A to Peg C:");
		moveDisks(n, 'A', 'C', 'B');
	}
	
	public static void moveDisks(int n, char fromTower, char toTower, char auxTower){
		if (n > 0){
			moveDisks(n - 1,fromTower, auxTower,toTower);
			System.out.println("Move a disk from " + fromTower + " to " + toTower);
			moveDisks(n - 1, auxTower, toTower, fromTower);
		}
	}
}
