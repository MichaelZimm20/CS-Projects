package uncp.csc1850.examples;

public class Examples {

	
//	public int min(int x, int y) {
//		if (x < y) {
//			return x;
//		} else {
//			return y;
//		}
//	}

	public int seeOut(int s, int o, int w, int n) {

		int so;
		int wn;

		so = Math.min(s, o);
		wn = Math.min(w, n);
		return Math.min(so, wn);
	}
	
	
	
	
	
	
	
}
