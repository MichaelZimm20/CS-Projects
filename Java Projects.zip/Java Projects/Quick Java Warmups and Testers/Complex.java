package uncp.csc1850.homework;

import java.text.DecimalFormat;

/**
 * This class will be able to display complex numbers. It will be able to format
 * real and imaginary .
 * 
 * @author Michael Zimmerman
 * @version 3.17.2015
 * 
 */
public class Complex {

	private double a = 0.0, b = 0.0;

	public Complex(double a1, double b1) {
		a = a1;
		b = b1;

	}

	public Complex(double a2) {
		a = a2;
		b = 0;
	}

	public Complex() {

	}

	public double getRealPart() {
		return a;
	}

	public double getImaginaryPart() {
		return b;
	}

	public void setReal(double real) {
		// Setting of the real
		a = real;
	}

	public void setImaginary(double imaginary) {
		// Setting of the imaginary
		b = imaginary;
	}

	public Complex conjugate() {
		Complex r = new Complex(a, -b);

		return r;

	}

	public Complex reciprocal() {
		double rec = (a * a) + (b * b);

		return new Complex(a / rec, -b / rec);

	}

	public String toString() {

		DecimalFormat formatter = new DecimalFormat("0.0##");
		String realNum = formatter.format(a);
		String imagNum = formatter.format(b);
		String format = realNum + " + " + imagNum + "i";
		return format;
	}

	public Complex(Complex num) {
		a = num.getRealPart();
		b = num.getImaginaryPart();
	}

	public Complex add(Complex com) {
		double c = com.getRealPart();
		double d = com.getImaginaryPart();
		return new Complex(a + c, b + d);
	}

	public Complex subtract(Complex s) {
		double c = s.getRealPart();
		double d = s.getImaginaryPart();
		return new Complex(a - c, b - d);

	}

	public Complex multiply(Complex com) {

		double c = com.getRealPart();
		double d = com.getImaginaryPart();

		double real = (a * c) - (b * d);
		double imag = (b * c) + (a * d);
		return new Complex(real, imag);

	}

	public Complex divide(Complex d) {
		Complex a1 = this;
		return a1.multiply(d.reciprocal());

	}

	public double abs() {

		return Math.sqrt((a * a) + (b * b));
	}

}	
	