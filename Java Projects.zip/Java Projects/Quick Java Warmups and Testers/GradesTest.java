package uncp.csc1850.examples;

import static org.junit.Assert.*;

import org.junit.Test;

public class GradesTest {

	

	@Test
	public void testGetGPA() {
		Grades grade = Grades.GRADE_A;
		assertEquals(4, grade.getGPA());
		assertEquals(3, Grades.GRADE_B.getGPA());
		//test the rest
//		assertEquals(3, Grades.GRADE_B.getGPA());
//		assertEquals(3, Grades.GRADE_B.getGPA());
//		assertEquals(3, Grades.GRADE_B.getGPA());
	}

	@Test
	public void testGetMessage() {
		fail("Not yet implemented"); //TODO
	}

	@Test
	public void testGetGrade() {
		Grades grade = Grades.getGrade(4);
		assertEquals(Grades.GRADE_B,grade);
		//test the rest
	}

}
