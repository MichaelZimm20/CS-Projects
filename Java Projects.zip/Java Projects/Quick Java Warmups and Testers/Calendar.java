package uncp.csc1850.examples;

import java.util.Scanner;

public class Calendar {
	

		
	//constructor 
	public Calendar (Scanner scan){
		//get array size
		//Create array
		
		//loop
			//read 3 ints
			//create the date 
			//add to the array
	}
	
	
	//TODO getter
	
	
	
	
	
	
	
	
	
	
	
	

}
