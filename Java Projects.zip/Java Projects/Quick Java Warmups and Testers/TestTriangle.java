package uncp.csc1850.homework;

import java.util.Scanner;

/**
 * @Rectangle.java
 * 
 *                 The following class will test the Area, and Perimeter of a
 *                 Triangle.
 * 
 * @author Michael Zimmerman
 * @version 2.24.15
 */

public class TestTriangle {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Enter in the 3 sides of the Triangle: ");
		double side1 = input.nextDouble();
		double side2 = input.nextDouble();
		double side3 = input.nextDouble();

		System.out.println("Enter the color of the Triangle: ");
		String color = input.next();

		System.out.println("Is the Triangle filled? True or False: ");
		boolean filled = input.nextBoolean();

		Triangle tri = new Triangle(side1, side2, side3);

		tri.setFilled(filled);
		tri.setColor(color);

		System.out.println(tri.toString());
		System.out.println("Triangle's Area : " + tri.getArea());
		System.out.println("Triangle's Perimeter : " + tri.getPerimeter());
		System.out.println("Triangle's Color : " + tri.getColor());
		System.out.println("Is the Triangle filled? : " + tri.isFilled());

		input.close();

	}

}
