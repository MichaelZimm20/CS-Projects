package uncp.csc1850.homework;

/**
 * @Square.java
 * 
 *              Given Java abstract class of Square and making as few changes as
 *              possible.
 * 
 * @author Michael Zimmerman
 * @version 3.17.15
 */
public abstract class Square {

	private int side;

	protected Square(int side) {
		this.setSide(side);
	}

	public int getSide() {
		return side;
	}

	public void setSide(int side) {
		this.side = side;
	}

	public abstract int Area();

	public abstract int getPerimeter();

	public String toString() {
		return "side: " + side + "Perimeter: " + getPerimeter() + "Area: "
				+ Area();

	}

}
