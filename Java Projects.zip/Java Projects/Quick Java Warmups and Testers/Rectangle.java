package uncp.csc1850.examples;

public class Rectangle extends Shape implements IArea {

	//extends - class with code
	//implements - interface 
	
	private int len;
	private int wid;
	
	public Rectangle(String nid,int length, int width){
		super(nid , 0, 0);
		len = length;
		wid = width;
	}
	
	@Override
	public double getArea() {
		return len * wid;
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return "Rectangle";
	}
	
	public String toString(){
		String str;
		
		str = len + " x " + wid;
		String pStr = super.toString();
		str = pStr + " " + str;		
		return str;
	}
	
}
