package uncp.csc1850.homework;

public class G extends F {

	
	
	 public G(){
		 System.out.println("Default G: " + value);
	 }
	 public G(int x){
		 value = x;
		 System.out.println("Non-Default G: " + value);
	 }
	 public void f(){
		 System.out.println("Using G's f().");
		 g();
	 }
	
	 
	 
	 public static void main(String[]args){
		 F f1 = new F(1), f2 = new F(), g1 = new G(2), g2 = new G();
		 f1.f();
		 f2.g();
		 g1.f();
		 g2.g();
	 }
}
