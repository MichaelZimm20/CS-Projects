package uncp.csc1850.examples;

public interface IArea {
	
	double getArea();

	
}
