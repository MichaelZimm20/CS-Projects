package uncp.csc1850.examples;


	public enum Grades {
		/** A */
		GRADE_A(4, "Good Job"),
		GRADE_B(3, "Okay"),
		GRADE_C(2, "Not Great"),
		GRADE_D(1, "Poor"),
		GRADE_F(0, "Really Poor");

	private int value;
	private String msg;

	private Grades(int score, String message) {
		value = score;
		msg = message;

	}

	/**
	 * 
	 * @return
	 */
	public int getGPA() {
		return value;
	}

	/**
	 * 
	 * @return
	 */
	public String getMessage() {
		return msg;
	}

	/**
	 * Gets the letter grade and return it
	 * @param g is the grade 
	 * @return the specific lettergrade
	 */
	public static Grades getGrade(int g) {
		Grades letterGrade;
		
		switch(g) {
		case 4:
			letterGrade = GRADE_A;
			break;
		case 3:
			letterGrade = GRADE_B;
			break;
		case 2:
			letterGrade = GRADE_C;
			break;
		case 1:
			letterGrade = GRADE_D;
			break;
		default:
			letterGrade = GRADE_F;
			
		}
		return letterGrade;
	}
	

}

