package uncp.csc1850.examples;

abstract public class Shape {

	// coordinates

	private int x;
	private int y;
	// color?
	// drawing attributes
	// id/name
	protected String id;

	// constructor
	public Shape(String nId, int nx, int ny) {
		id = nId;
		x = nx;
		y = ny;

	}

	public String getId() {
		return id;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public void setPosition(int nx, int ny) {
		x = nx;
		y = ny;
	}

	abstract public String getType();

	public String toString(){
		return id + ": " + getType()
				+ "@ (" + x + ", " + y + ")";
		
	}













}
