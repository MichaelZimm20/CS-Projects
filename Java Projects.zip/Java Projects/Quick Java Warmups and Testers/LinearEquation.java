package uncp.csc1850.homework;

/**
 * Class named Linear Equation for a 2 x 2 system of linear equations
 * 
 * @author Michael Zimmerman
 * @version 1/27/15
 */
public class LinearEquation {

	private double a, b, c, d, e, f;
	private double x, y;

	// private char b;
	// private char c;
	// private char d;
	// private char e;
	// private char f;

	public LinearEquation(double a, double b, double c, double d, double e,
			double f) {

		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.e = e;
		this.f = f;
	}

	public double getA() {
		return a;
	}

	public double getB() {
		return b;
	}

	public double getC() {
		return c;
	}

	public double getD() {
		return d;
	}

	public double getE() {
		return e;
	}

	public double getF() {
		return f;
	}

	public boolean isSolvable() {
		if ((a * d) - (b * c) == 0) {
			return (a * d) - (b * c) != 0;
		}
		return true;

	}

	public double getX() {
		x = ((e * d) - (b * f)) / ((a * d) - (b * c));
		return x;
	}

	public double getY() {
		y = ((a * f) - (e * c)) / ((a * d) - (b * c));
		return y;
	}
}
