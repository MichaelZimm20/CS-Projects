package uncp.csc1850.homework;

public class Homework3_part2 {
	

	public static void main(String args[]){
		int i1 = new Integer("128.5");
		Double i2 = new Double(234);
		
		Integer i3 = Integer.valueOf(0);
		Integer i4 = Integer.parseInt("15", 8);
		int i5 = (Double.valueOf("3.45")).intValue();
		//Double d1 = new Double("12").intValue(); //change Double to int 
		
		//int i6 = new Integer("23").doubleValue();// change int to double
		
		//int i7 = (Double.valueOf("3.45").floatValue()); // change int to float
		
		double d2 = (Double.valueOf("3.45"));
		Double s = Double.valueOf("3.45");
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
