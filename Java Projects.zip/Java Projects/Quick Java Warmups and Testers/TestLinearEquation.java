package uncp.csc1850.homework;

import java.util.Scanner;

/**
 * Class named Linear Equation for a 2 x 2 system of linear equations
 * 
 * @author Michael Zimmerman
 * @version 1/27/15
 */
public class TestLinearEquation {

	public static void main(String[] args) {

		System.out.print("Enter a, b, c, d, e, f: ");
		Scanner input = new Scanner(System.in);
		double a = input.nextDouble();
		double b = input.nextDouble();
		double c = input.nextDouble();
		double d = input.nextDouble();
		double e = input.nextDouble();
		double f = input.nextDouble();
//		double x = input.nextDouble();
//		double y = input.nextDouble();

		LinearEquation linear1 = new LinearEquation(a, b, c, d, e, f);
		boolean line = linear1.isSolvable();

		
		if (((a*d)-(b*c) < 0) == true) {
			System.out.println("The equation has no roots");
		} else {
			System.out.println("x is " + linear1.getX() + "and y is " + linear1.getY() + line);
		}

		input.close();

	}

}
