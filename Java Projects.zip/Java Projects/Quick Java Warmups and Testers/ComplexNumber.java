package uncp.csc1850.homework;

import java.text.DecimalFormat;

/**
 * 
 * This class will be able to display the complex number .It will be able to
 * format <real> +<imaginary>. It will also be able to get the conjugate of a
 * complex number
 * 
 * 
 * @author maz002
 * @version 2014.20.3
 */

public class ComplexNumber {

	// 5+4i -> 5-4i
	// 20i+6 -> 20i-6
	// (10+2i)(2+10i) -> (10-2i)(2-10i)
	// (4i+4)/(2i+2) -> (4i-4)/(2i-2)

	private double realPart;
	private double imaginaryPart;

	/**
	 * A constructor for the ComplexNumber class for the real and imaginary.
	 * 
	 * @param real
	 *            The new real part to store
	 * @param imaginary
	 *            Will display anything thats not a real number
	 */
	public ComplexNumber(double real, double imaginary) {
		// A constructor for the real and imaginary part.
		realPart = real;
		imaginaryPart = imaginary;
	}

	/**
	 * A constructor for the ComplexNumber object
	 * 
	 * @param real
	 *            Used to initialize the real part of the class.
	 */
	public ComplexNumber(double real) {
		// A constructor for the real part only
		realPart = real;
		imaginaryPart = 0;

	}

	/**
	 * This method gets and returns the real part of a number.
	 * 
	 * @return The real part of the Number
	 */
	public double getReal() {
		// Returning the realPart
		return realPart;
	}

	/**
	 * This method gets and returns the imaginary part of a number
	 * 
	 * @return The imaginary part of the Number
	 */
	public double getImaginary() {
		// Returning the imaginaryPart
		return imaginaryPart;
	}

	/**
	 * The method sets the instance to the real number.
	 * 
	 * @param real
	 *            Changes instance to real
	 */
	public void setReal(double real) {
		// Setting of the real
		realPart = real;
	}

	/**
	 * The method sets the instance to a imaginary number.
	 * 
	 * @param imaginary
	 *            Changes instance to imaginary.
	 */
	public void setImaginary(double imaginary) {
		// Setting of the imaginary
		imaginaryPart = imaginary;
	}

	/**
	 * The conjugate method returns the conjugated form of the current object's
	 * value.
	 * 
	 * @return the conjugated of the current object's value
	 */
	public ComplexNumber conjugate() {
		// comjugate method and ComplexNumber Object and return
		ComplexNumber real1 = new ComplexNumber(realPart, -imaginaryPart);
		return real1;
	}

	/**
	 * Formatting the numbers of the real and imaginary numbers.
	 * 
	 * @return The format of the realPart and the imaginaryPart
	 */
	public String toString() {
		// Format of the realPart, and imaginaryPart output, converting the
		// numbers from doubles toString
		DecimalFormat formatter = new DecimalFormat("0.0##");
		String realNum = formatter.format(realPart);
		String imagNum = formatter.format(imaginaryPart);
		String format = realNum + " + " + imagNum + "i ";
		return format;
	}

	// (1.5 + 1.5i) + (1.0 + -4.6i) = 2.5 + -3.1i,
	// (2.5 + 1.5i) - (2.0 + -5.7i) = 0.5 + 7.2i,
	// (0.5 + 1.5i) * (2.0 + -8.5i) = 7.75 + 0.75i
	// (4.7 + 3.5i) + (2.30 + -9.8i) = 7.0 + -6.3i,

	/**
	 * A copy constructor used to copy the real and imaginary.
	 * 
	 * @param num
	 *            The new value to store
	 */
	public ComplexNumber(ComplexNumber num) {
		realPart = num.getReal();
		imaginaryPart = num.getImaginary();
	}

	/**
	 * A null constructor for the real and imaginary
	 */
	public ComplexNumber() {
		realPart = 0;
		imaginaryPart = 0;

	}

	/**
	 * The object returned from the method should a new ComplexNumber object
	 * 
	 * @param b
	 *            the ComplexNumber using b
	 * @return returning the output of nr.
	 */
	public ComplexNumber add(ComplexNumber b) {
		// add values
		ComplexNumber nr = new ComplexNumber(realPart + b.getReal(),
				imaginaryPart + b.getImaginary());
		return nr;

	}

	/**
	 * The object returned from the method should return the difference of the
	 * ComplexNumber object.
	 * 
	 * @param s
	 *            is the parameter to return the subtraction
	 * @return the subtraction part of the values
	 */
	public ComplexNumber subtract(ComplexNumber s) {
		// subtract values
		ComplexNumber nr2 = new ComplexNumber(realPart - s.getReal(),
				imaginaryPart - s.getImaginary());
		return nr2;
	}

	/**
	 * Multiply the values of the real and imaginary part
	 * 
	 * @param m
	 *            multiply the values
	 * @return the multiplied values
	 */
	public ComplexNumber multiply(ComplexNumber m) {
		// multiply the values together

		double real2;
		double imag2;
		double r = m.getReal();
		double im = m.getImaginary();

		real2 = (realPart * r) - (imaginaryPart * im);
		imag2 = (imaginaryPart * r) + (realPart * im);
		ComplexNumber nr3 = new ComplexNumber(real2, imag2);

		return nr3;

	}
}
