package uncp.csc1850.examples;

import static org.junit.Assert.*;


import org.junit.Test;

public class IAreaTest {


	@Test
	public void testGetArea() {
		IArea a1 = new Circle(1);
		assertEquals(Math.PI, a1.getArea(), 0.00001);
		
//		IArea a2 = new Rectangle(4, 7842);
//		assertEquals(4 * 7842, a2.getArea(), 0.00001);
//		
		//a1 = new Rectangle(2,5);
		
//		a1.getRadius();
//		Circle c1 = new Circle(1);
//		c1.getRadius();
//		a1 = c1;
//		a1.getRadius();
		
	}

	
	
	@Test
	public void testRect(){
		 Rectangle r = new Rectangle("r1", 4, 3);
		 assertEquals("r1", r.getId());
		 assertEquals("Rectangle", r.getType());
		 
		 Shape s = r;
		 
		 assertEquals("Rectangle", s.getType());
		 
		 System.out.println(r.toString());
		 r.setPosition(15, 20);
		 System.out.println(r.toString());
//		 assertEquals("Rectangle", r.setPosition(15, 20));
		 
		 
	}
	
	
	
	
	
}
