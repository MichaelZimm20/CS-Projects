package uncp.csc1850.homework;

import java.util.Scanner;

public class TestComplex {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		System.out.println("Enter the first complex numbers(real number): ");
		double a = input.nextDouble();

		System.out
				.println("Enter the first complex numbers(Imaginary number): ");
		double b = input.nextDouble();

		System.out.println("Enter the second complex numbers(real number): ");
		double c = input.nextDouble();

		System.out
				.println("Enter the second complex numbers(Imaginary number): ");
		double d = input.nextDouble();

		Complex c1 = new Complex(a, b);
		Complex c2 = new Complex(c, d);

		System.out.println("(" + c1 + ") + (" + c2 + ") = " + c1.add(c2));
		System.out.println("(" + c1 + ") - (" + c2 + ") = " + c1.subtract(c2));
		System.out.println("(" + c1 + ") * (" + c2 + ") = " + c1.multiply(c2));
		System.out.println("(" + c1 + ") / (" + c2 + ") = " + c1.divide(c2));
		System.out.println("|(" + c1 + ")| = " + c1.abs());

		input.close();

	}
}
