package uncp.csc1850.homework;

public class F {
	
	protected int value;
	public F(){
		System.out.println("Default F: " + value);
	}
	public F(int x){
		value = x;
		System.out.println("Non-default F: " + value );
		
	}
	 public void f(){
		 System.out.println("Using F's f().");
	 }
	 public void g(){
		 System.out.println("Using F's g():");
		 
	 }
	
	 
	 
	 
	 
}
