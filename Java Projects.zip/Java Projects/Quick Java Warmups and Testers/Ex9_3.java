package uncp.csc1850.homework;
import java.util.Date;
/**
 * Writes a program that creates a Date object
 * @author Michael Zimmerman
 *@version 1.20.15
 */
public class Ex9_3 {
	
	public static void main (String args[]){
		
		
		Date date = new Date();
		System.out.println(date.toString());
		
		Date date1 = new Date(100000);
		System.out.println(date1.toString());
		Date date0 = new Date(100000 * 1000);
		System.out.println(date0.toString());
		Date date2 = new Date(1000000);
		System.out.println(date2.toString());
		Date date3 = new Date(10000000);
		System.out.println(date3.toString());
		Date date4 = new Date(100000000);
		System.out.println(date4.toString());
		Date date5 = new Date(1000000000);
		System.out.println(date5.toString());
		
		
		//long time = System.nanoTime() * 1000;
//		while(date.getTime() >= 10000){
//			 date = new Date(100000 * 1000);
//		}
		

		System.out.println("The number of miliseconds since 1/1/1970 GMT is: " + date.getTime());
	
		
		
		
	}
	
//	for (int i =10000; i < date.getSeconds(); i++ ){
//	System.out.println(date.getDate());
//	
//}

//	private int time = 10000;
//	private String date; 
//	
//	public Ex9_3() {
//
//	}
//	public Ex9_3(int time, String date){
//
//		this.time = time;
//		this.date = date;
//
//
//	}
//	
//	public void Date(int year, int month, int date, int hrs, int min, int sec){
//		return;
//		
//	}
//	
//	public String toString(){
//		System.out.println(time);
//		return date.toString();
//	}

}
