package uncp.csc1850.homework;

/**
 * @Rectangle.java
 *
 * The following class will test the Rectangle class.
 *
 * @author Michael Zimmerman
 * @version 1.18.15
 */
public class TestRectangle {
	
	public static void main(String[]args){
		Rectangle rect = new Rectangle(4,40);
		System.out.println(rect.toString());
		
		Rectangle rect1 = new Rectangle(3.5,35.9);
		System.out.println(rect1.toString());
	}

}
